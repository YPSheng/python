from django.apps import AppConfig


class AxfConfig(AppConfig):
    name = 'axf'
