from django.db import models

# Create your models here.
class User(models.Model):
    useraccount = models.CharField(max_length=20, unique=True)
    uname = models.CharField(max_length=10,unique=True)
    uemail = models.EmailField(unique=True)
    utel = models.CharField(max_length=11,unique=True)
    upassword = models.CharField(max_length=16)
    # isLogin = models.BooleanField()
    userimg = models.CharField(max_length=200)
    userRank = models.CharField(max_length=150)   #等级
    userToken = models.CharField(max_length=50)
    @classmethod
    def createuser(cls,useraccount,uname,uemail,utel,upassword,userimg,userRank,userToken):
        u = cls(useraccount=useraccount,uname=uname,uemail=uemail,utel=utel,upassword=upassword,userimg=userimg,userRank=userRank,userToken=userToken)
        return u



class CartManager1(models.Manager):
    def get_queryset(self):
        return super(CartManager1,self).get_queryset().filter(isDelete=False)


class CartManager2(models.Manager):
    def get_queryset(self):
        return super(CartManager2, self).get_queryset().filter(isDelete=True)

class Cart(models.Model):
    userAcount = models.CharField(max_length=20)
    productid = models.CharField(max_length=10)
    productnum = models.IntegerField()
    productprice = models.CharField(max_length=10)
    isChose = models.BooleanField(default=True)
    productimg = models.CharField(max_length=200)
    productname = models.CharField(max_length=200)
    orderid = models.CharField(max_length=20,default='0')
    isDelete = models.BooleanField(default=False)
    objects = CartManager1()    #自定义对象
    obj2 = CartManager2()       #自定义对象
    @classmethod
    def createcart(cls,userAcount,productid,productnum,productprice,isChose,productimg,productname,isDelete):
        c = cls(userAcount = userAcount,productid = productid,productnum=productnum,productprice=productprice,isChose=isChose,productimg=productimg,productname=productname,isDelete=isDelete)
        return c

class Order(models.Model):
    orderid = models.CharField(max_length=20)
    userid = models.CharField(max_length=20)
    progress = models.IntegerField()

    @classmethod
    def createorder(cls,orderid, userid, progress):
        o = cls(orderid=orderid, userid=userid, progress=progress)
        return o