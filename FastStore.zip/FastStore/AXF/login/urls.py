from django.conf.urls import url

from login import views

urlpatterns = [
    url(r'^register/',views.register,name='register'),
    url(r'^verify_code',views.createCode,name='code'),
    url(r'^check/',views.check,name='check'),
    url(r'^registercheckname/',views.registercheckname,name='registercheckname'),
    url(r'^registercheckemail/',views.registercheckemail,name='registercheckemail'),
    url(r'^registerchecktel/',views.registerchecktel,name='registerchecktel'),
    url(r'^registersuc/',views.registersuc,name='registersuc'),
    url(r'^success/',views.success,name='success'),
    url(r'^loginout/',views.loginout,name='loginout'),
    url(r'^',views.login,name='login'),
]