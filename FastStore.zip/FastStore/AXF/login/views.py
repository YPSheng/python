import random

import os
from PIL import Image, ImageDraw, ImageFont
from django.http import JsonResponse, request
from django.shortcuts import render,HttpResponse,HttpResponseRedirect
from login.models import User
from django.urls import reverse
from django.utils.six import BytesIO
import time
# Create your views here.


# 登录页面
def login(request):
    return render(request,'login.html')


# 注册页面
def register(request):
    return render(request,'register.html')


# 生成验证码
def createCode(request):
    bgcolor = (random.randrange(20,100),random.randrange(20,100),255)
    width = 100
    height = 25
    #创建画面对象
    image = Image.new("RGB",(width,height),bgcolor)
    #创建画笔对象
    draw = ImageDraw.Draw(image)
    #使用画笔的point（）函数回执噪点，模糊画面，防止被机器识别
    for i in range(0,300):
        #噪点绘制范围
        xy = (random.randrange(0,width),random.randrange(0,height))
        #绘制噪点颜色
        fill = (random.randrange(20,100),255,random.randrange(20,100))
        #绘制噪点
        draw.point(xy,fill)
        #定义验证码的备选值
        str1 = 'ABCD123EFGHIJK456LMNOPQRS789TUVWXYZ0'
        #随机选择四个作为验证码值
        rand_str = ''

        for i in range(0,4):
            rand_str += str1[random.randrange(0,len(str1))]

        #构造字体对象。默认的，这里不修改了
        font = ImageFont.truetype('FreeMono.ttf', 23)
        #构造字体颜色
        fontcolor = (255,random.randrange(0,255),random.randrange(0,255))

        #绘制验证码的4个字
        draw.text((5,2),rand_str[0],font=font,fill=fontcolor)
        draw.text((25,2),rand_str[1],font=font,fill=fontcolor)
        draw.text((50,2),rand_str[2],font=font,fill=fontcolor)
        draw.text((75,2),rand_str[3],font=font,fill=fontcolor)

        #用完画笔，释放画笔
        del draw
        #存入session中，用于作进一步验证
        request.session['vcerifycode'] = rand_str
        buf = BytesIO()
        #保存文件在内存中，文件类型为png
        image.save(buf,'png')
        #将内存中的图片作为数据返回给客户端，MIME类型图片PNG
        return HttpResponse(buf.getvalue(),'image/png')
# def check(request):


#验证用户名
def registercheckname(request):


    preCheck = request.GET.get('username')
    # print(preCheck)
    # 从数据库查询该用户名是否存在
    if len(User.objects.filter(uname=preCheck)) == 0:
        context = {'status': '用户名可用'}
        print("123456")
    else:
        context = {'status': '用户名已存在'}

    return JsonResponse(context)


#验证邮箱
def registercheckemail(request):
    # 从session获取email
    preCheck = request.GET.get('email')
    # print(preCheck)
    # 判断数据库里该邮箱存不存在
    if len(User.objects.filter(uemail=preCheck)) == 0:
        context = {'status': '邮箱可用'}
        # print("123456")
    else:
        context = {'status': '此邮箱已注册'}

    return JsonResponse(context)

#验证手机号
def registerchecktel(request):
    preCheck = request.GET.get('tel')
    # print(preCheck)
    if len(User.objects.filter(utel=preCheck)) == 0:
        context = {'status': '此手机号可用'}
        # print("123456")
    else:
        context = {'status': '此手机号已注册'}

    return JsonResponse(context)

# 注册用户
def registersuc(request):
    username = request.GET.get('username')
    password = request.GET.get('password')
    email = request.GET.get('email')
    tel = request.GET.get('tel')
    # username = request.GET.get('username')
    num = int(random.random()*1000000)
    # user = User()
    useraccount = num
    uname = username
    upassword = password
    uemail = email
    utel = tel
    # userimg = '1'
    userRank = num
    token = time.time() + random.randrange(1,100000)
    userToken = str(token)
    # f = request.FILES["userimg"]
    # userimg = os.path.join('static/img', str(num) + ".png")
    # with open(userimg, "wb") as fp:
    #     for data in f.chunks():
    #         fp.write(data)
    userimg = '1111'
    user = User.createuser(useraccount,uname,uemail,utel,upassword,userimg,userRank,userToken)
    # user.isLogin = 1
    user.save()
    request.session['username'] = username
    request.session['token'] = userToken
    return JsonResponse({'status':'恭喜你注册成功'})

#登录检测
def check(request):
    username = request.POST.get('username')
    # email = request.POST.get('email')
    # tel = request.POST.get('tel')
    pasone = request.POST.get('password')
    vcode = request.POST.get('vcode')
    vcode_session = request.session.get('vcerifycode')
    # user = User()
    # pastwo = request.POST.get('passwordtwo')
    # 判断用户名是否存在
    if len(User.objects.all().filter(uname=username)) != 0:
        namepas = User.objects.all().filter(uname=username)[0].upassword
        # emailpas = User.objects.all().filter(uemail=username).upassword
        # telpas = User.objects.all().filter(utel=username).upassword
        # 判断密码是否正确
        if pasone == namepas:
            if vcode != vcode_session:
                return JsonResponse({'msg': 'fail_verifuy'})
            else:
                # request.session['isLogin'] = True
                #登录成功
                token = time.time() + random.randrange(1,100000)
                user = User.objects.get(uname=username)
                user.userToken = str(token)
                user.save()
                # 将username添加进session
                request.session['username'] = user.uname
                # request.session['password'] = pasone
                request.session['token'] = user.userToken
                return JsonResponse({'msg': 'ok'})
        #密码错误的话，返回错误信息
        else:
            content = {'msg': 'fail_user'}
            return JsonResponse(content)
    # 用户名不对的话，返回错误信息
    else:
        return JsonResponse({'msg':'fail_user'})

#登录成功
def success(request):
    # token = request.session.get('token')
    # username = request.session.get('username')
    # userRank = User.objects.filter(uname=username)[0].userRank
    # 如果用户登陆成功，会获取到一个随机的token，如果token存在就证明用户登录成功
    if request.session.get('token'):
        username = request.session.get('username')
        userRank = User.objects.filter(uname=username)[0].userRank
        return render(request,'mine.html',{'username':username,'userRank':userRank})
    else:
        return HttpResponseRedirect('/login/')

# 退出登录，删除session里的token
def loginout(request):
    # request.session['isLogin'] = False
    del request.session['token']
    return render(request,'login.html')