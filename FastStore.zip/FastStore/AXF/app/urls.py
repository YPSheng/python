from django.conf.urls import url

from app import views

urlpatterns = [
    # url(r'^admin/', admin.site.urls),
    url(r'^home/',views.home,name='home'),
    url(r'^markettwo/(\w+)/(\w+)/(\w+)/',views.markettwo,name='markettwo'),
    url(r'^market/',views.market,name='market'),
    url(r'^cart/',views.cart,name='cart'),
    url(r'^changecart/(\d+)/',views.changecart,name='changecart'),
    url(r'^saveorder/',views.saveorder,name='saveorder'),
    url(r'^mine/',views.mine,name='mine'),
    url(r'^checkall/(\d+)/',views.checkall,name='checkall')
]
