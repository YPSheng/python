from django.db import models

# Create your models here.
class Wheel(models.Model):
    img = models.CharField(max_length=200)
    name = models.CharField(max_length=20)
    trackid = models.CharField(max_length=10)
    class Meta:
        db_table = 'axf_wheel'

class topMenu(models.Model):
    img = models.CharField(max_length=200)
    name = models.CharField(max_length=20)
    trackid = models.CharField(max_length=10)

    class Meta:
        db_table = 'axf_nav'

class MustBuy(models.Model):
    img = models.CharField(max_length=200)
    name = models.CharField(max_length=20)
    trackid = models.CharField(max_length=10)

    class Meta:
        db_table = 'axf_mustbuy'

class Shop(models.Model):
    img = models.CharField(max_length=200)
    name = models.CharField(max_length=20)
    trackid = models.CharField(max_length=10)
    class Meta:
        db_table = 'axf_shop'

class mainShow(models.Model):
    trackid = models.CharField(max_length=10)
    name = models.CharField(max_length=20)
    img = models.CharField(max_length=200)
    categoryid = models.CharField(max_length=10)
    brandname = models.CharField(max_length=20)
    img1 = models.CharField(max_length=200)
    childcid1 = models.CharField(max_length=10)
    productid1 = models.CharField(max_length=10)
    longname1 = models.CharField(max_length=40)
    price1 = models.CharField(max_length=10)
    marketprice1 = models.CharField(max_length=10)
    img2 = models.CharField(max_length=200)
    childcid2 = models.CharField(max_length=10)
    productid2 = models.CharField(max_length=10)
    longname2 = models.CharField(max_length=40)
    price2 = models.CharField(max_length=10)
    marketprice2 = models.CharField(max_length=10)
    img3 = models.CharField(max_length=200)
    childcid3 = models.CharField(max_length=10)
    productid3 = models.CharField(max_length=10)
    longname3 = models.CharField(max_length=40)
    price3 = models.CharField(max_length=10)
    marketprice3 = models.CharField(max_length=10)
    class Meta:
        db_table = 'axf_mainshow'
class FoodsType(models.Model):
    typeid = models.CharField(max_length=10)
    typename = models.CharField(max_length=200)
    childtypenames = models.CharField(max_length=100)
    typesort = models.CharField(max_length=10)

    class Meta:
        db_table = 'axf_foodtypes'

class Goods(models.Model):
    productid = models.CharField(max_length=10)
    productimg  = models.CharField(max_length=200)
    productname = models.CharField(max_length=200)
    productlongname = models.CharField(max_length=300)
    isxf = models.CharField(max_length=20)
    pmdesc = models.CharField(max_length=20)
    specifics = models.CharField(max_length=20)
    price = models.CharField(max_length=20)
    marketprice = models.CharField(max_length=20)
    categoryid = models.CharField(max_length=20)
    childcid = models.CharField(max_length=20)
    childcidname = models.CharField(max_length=200)
    dealerid = models.CharField(max_length=20)
    storenums = models.CharField(max_length=20)
    productnum = models.CharField(max_length=20)

    class Meta:
        db_table = 'axf_goods'