import time
from random import randrange

from django.shortcuts import render,HttpResponse
from app.models import Wheel,topMenu,MustBuy,Shop,mainShow,FoodsType,Goods
from login.models import User, Cart, Order
from django.http import JsonResponse, request
# Create your views here.

# 首页
def home(request):
    title = '首页'
    # 轮播图片
    wheels = Wheel.objects.all()
    topmenus = topMenu.objects.all()
    # 必买模块
    mustbuies = MustBuy.objects.all()
    cvs = Shop.objects.all()
    # 各个模块显示图片
    cvstwo = Shop.objects.all()[3:7]
    cvsthree = Shop.objects.all()[7:]
    mainshows = mainShow.objects.all()
    context = {'pageTitle':title,'wheels':wheels,'topmenus':topmenus,'mustbuies':mustbuies,'cvs':cvs,'cvstwo':cvstwo,'cvsthree':cvsthree,'mainshows':mainshows}
    return render(request, 'home.html',context)

#商场物品详情
def market(request):
    title = '闪购'
    types = FoodsType.objects.all()
    goods = Goods.objects.all()[1:10]
    datas = Cart.objects.all()
    # token = request.session.get('token')
    # user = User.objects.get(userToken=token)
    # data = []
    # if token == None:
    #     data = [0]
    # else:
    #     carts = Cart.objects.filter(userAcount=user.useraccount)
    #     if len(carts) != 0:
    #         data = carts
    context = {'pageTitle':title,'types':types,'goods':goods,'data':0}
    return render(request, 'market.html',context)


#修改购物车判断用户是否登录
def changecart(request,flag):
    #判断用户是否登录
    token = request.session.get('token')
    # print('token是',token)
    if token == None:
        #没登录
        return JsonResponse({'data':-1,'status':'error'})
    productid = request.POST.get('productid')
    # 获取该物品信息
    product = Goods.objects.get(productid=productid)
    # 获取当前用户信息
    user = User.objects.get(userToken=token)
    # print("user是：",user.useraccount)
    #添加物品到购物车
    if flag == '0':
        if product.storenums == 0:
            return JsonResponse({'data':-2,'status':'error'})
        carts = Cart.objects.filter(userAcount=user.useraccount)
        c = None
        # 判断该订单是否为0
        if carts.count() == 0:
            #直接增加一条订单
            c = Cart.createcart(user.useraccount,productid,1,product.price,True,product.productimg,product.productlongname,False)
            c.save()
            return render(request,'market.html')
        else:
            # 如果存在，就在该购物车里修改该商品购买信息
            try:
                c = carts.get(productid=productid)
                #修改数量和价格
                c.productnum =int(c.productnum) + 1
                c.productprice = "%.2f"%(float(product.price)*c.productnum)
                c.save()
                # return render(request, 'market.html')
            except Cart.DoesNotExist as e:
                #直接增加一条订单
                #该物品信息不存在，就直接增加一条新的订单
                c =  Cart.createcart(user.useraccount,productid,1,product.price,True,product.productimg,product.productlongname,False)
                c.save()

            #库存减一
            product.storenums = int(product.storenums) - 1
            product.save()
            carsum = 0
            cartlist = Cart.objects.filter(userAcount=user.useraccount)
            for i in cartlist:
                if i.isChose:
                    carsum += float(i.productprice)
            return JsonResponse({'data':c.productnum,'price':c.productprice,'status':'success','carsum':carsum})
    #取消购物车的某个物品
    elif flag == '1':
        carts = Cart.objects.filter(userAcount=user.useraccount)
        c = None
        # 如果该商品购物车里的数量为0，则从购物车删除该商品
        if carts.count() == 0:
            return JsonResponse({'data':-2,'status':'error'})
        else:
            try:
                c = carts.get(productid=productid)
                #修改数量和价格
                c.productnum = int(c.productnum)-1
                #计算购物车里该商品的总共价格
                c.productprice = '%.2f'%(float(product.price)*c.productnum)
                if c.productnum == 0:
                    c.delete()
                else:
                    c.save()
            except Cart.DoesNotExist as e:
                return JsonResponse({'data':-2,"status":'error'})
            #库存加一
            product.storenums = int(product.storenums)+1
            product.save()
            # return render(request,'market.html')
            # 计算购物车选中的物品总价
            carsum = 0
            cartlist = Cart.objects.filter(userAcount=user.useraccount)
            for i in cartlist:
                if i.isChose:
                    carsum += float(i.productprice)
            return JsonResponse({'data': c.productnum,'price': c.productprice,'status': 'success','carsum':carsum})
    elif flag == '2':
        # 查询该用户的购物车信息
        carts = Cart.objects.filter(userAcount=user.useraccount)
        # print('1111',carts)
        # 过去要操作的该物品的信息
        c = carts.get(productid=productid)
        c.isChose = not c.isChose   #去相反
        c.save()
        carsum = 0
        str = ""
        carts = Cart.objects.filter(userAcount=user.useraccount)
        for c in carts:
            if c.isChose:
                str='checked'
                carsum += float(c.productprice)
        return JsonResponse({'data':str,"status":'success','carsum':carsum,'isChose':c.isChose})

#判断用户是否登录
def saveorder(request):
    # 从session中获取token的值
    token = request.session.get('token')
    # 通过判断是否存在token来判断用户是否登录
    if token == None:
        # 如果没有登录就返回到登录界面
        return JsonResponse({'data':-1,'status':'error'})
    # 获取用户信息，购物车选中物品信息，然后保存到该表中
    user = User.objects.get(userToken=token)
    carts = Cart.objects.filter(isChose = True)
    oid = time.time() + randrange(1,100000)
    oid = "%d"%oid
    o = Order.createorder(oid,user.useraccount,0)
    o.save()
    # 保存到该表里的数据，在购物车里不可见，已经支付成功
    for item in carts:
        item.isDelete = True
        item.orderid = oid
        item.save()
    return JsonResponse({"staus":"success"})


# 商品信息，筛选

def markettwo(request,typeid,child,order):
    title = '闪购'
    types = FoodsType.objects.all()
    # if cate == '0' and child == '0':
    # 处理获取到的物品类型数据
    childtypes = types.filter(typeid=typeid)[0].childtypenames.split('#')
    childids = {}
    # 将数据保存为字典，方便获取
    for i in childtypes:
        # childnames.append(i.split(':')[0])
        print(i)

        childids[i.split(':')[0]] = i.split(':')[1]
    # print(child)
    # 综合排序
    if order == '0':
        orderRule = 'id'
    elif order == '1':
        orderRule = 'price'
    elif order == '2':
        orderRule = '-price'
    else:
        orderRule = 'productnum'

    if child == '0':
        goods = Goods.objects.all().filter(categoryid=typeid).order_by(orderRule)
    else:
        goods = Goods.objects.all().filter(categoryid=typeid).filter(childcid=child).order_by(orderRule)
    context = {'pageTitle':title,'types':types,'goods':goods,'childs':childids,'typeid':typeid,'order':order,'childids':childids,'child':child}

    return render(request, 'market.html',context)


# 购物车
def cart(request):
    title = '购物车'
    carlist = []
    # 判断用户是否登录
    token = request.session.get('token')
    #如果token不为None，则证明该用户登录成功
    if token != None:
        user  = User.objects.get(userToken=token)
        carsum = 0
        carlist = Cart()
        carlist = Cart.objects.filter(userAcount=user.useraccount)
        # 获取物品信息，然后在获取商品价格
        goods = Goods.objects.all()
        for i in carlist:
            # print(i.isChose)
            i.isChose = 0
            i.save()
            # carsum += float(i.productprice)
        # carsum = Cart.objects.all().aggregate(sum('productprice'))
        context = {'pageTitle':title,'carlist':carlist,'carsum':carsum,'goods':goods}
    else:

        # context = {'pageTitle':title}
        return  render(request,'login.html')
    return render(request, 'cart.html',context)

# def changecartadd(request):
#     # car = Cart()
#     # car.id = request.POST.get('pid')
#     # goodsname = request.POST.get('goodsname')
#     # car.goodsnames = goodsname
#     # car.goodsprice = Goods.objects.all().filter(productname=goodsname).price
#     pid = request.POST.get('productid')
#     if request.session['isLogin']:
#         print('获取到的：',pid)
#         pid = 1 + int(pid)
#         print('然后：',pid)
#         content = {'status':'success','data':pid}
#         return JsonResponse(content)
#     else:
#         return JsonResponse({'data':'-1'})

# 个人中心页面
def mine(request):
    title = '个人中心'
    token = request.session.get('token')
    # 先判断是否登录
    if token != None:
    # if  request.session.get('username'):
        user = User()
        username = request.session.get('username')
        userRank = User.objects.filter(uname=username)[0].userRank
        context = {'pageTitle':title,'username':username,'userRank':userRank,'logina':''}
    else:
        context = {'pageTitle':title,'username':'未登录','userRank':'','logina':'登录'}
    return render(request, 'mine.html',context)

# 全选与取消全选
def checkall(request,pid):
    token = request.session.get('token')
    # 先判断是否登录
    if token == None:
        return JsonResponse({'data':-1,'status':'error'})   #未登录
    user = User.objects.get(userToken=token)
    # 获取用户的购物车信息
    carts = Cart.objects.filter(userAcount=user.useraccount)
    carsum = 0
    # 如果全选，那么设置购物车每个商品的isChose为True，选中状态
    if pid == '1':
        for i in carts:
            i.isChose = 1
            i.save()
            carsum = carsum + float(i.productprice)   #计算全选后的价格
    # 取消全选按钮选中，修改所有商品的isChose为False，取消选中，此时总价carsum默认为0
    elif pid == '0':
        for j in carts:
            j.isChose = 0
            j.save()
    return JsonResponse({'status':'success','carsum':carsum})