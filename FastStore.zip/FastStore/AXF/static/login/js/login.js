
        $(function () {
            $('#btnLogin').click(function () {
                // $('username').reset;

                csrf = $('input').val();
                username = $('#username').val();
                password = $('#password').val();
                vcode = $('#vcode').val();
                url = '/login/check/';
                $.post(url,{
                    'csrfmiddlewaretoken':csrf,
                    'username':username,
                    'password':password,
                    'vcode':vcode
                },function(data){
                    console.log(data.msg);
                    if(data.msg == 'ok'){
                        location.href = '/login/success/'  /*跳转成功*/
                    }
                    else if(data.msg == 'fail_user'){
                        $('#errorMsg').show().text('亲，用户名或者密码错误')
                    }else if (data.msg=='fail_verifuy'){
                        $('#errorMsg').show().text('亲，验证码错误')
                    }

                })
            });

            $('#change').on('click',function () {
                $('#imgvcode').prop('src','http://127.0.0.1:8000/login/verify_code?'+Math.random()*10000);
                // alert('aaaaaaaaaa')
            })
        });