
        $(function () {
            $('#username').change(function () {
                var preUsername = $(this).val();
                var url = '/login/registercheckname/';
                $.get(url,{'username':preUsername},function (data) {
                    $('.user').html(data.status)
                })
            });
            $('#email').change(function () {
                var email = $(this).val();
                var url = '/login/registercheckemail/';
                $.get(url,{'email':email},function (data) {
                    $('.ema').html(data.status)
                })
            });
             $('#tel').change(function () {
                var tel = $(this).val();
                var url = '/login/registerchecktel/';
                $.get(url,{'tel':tel},function (data) {
                    $('.ema').html(data.status)
                })
            });

             $('#btnRegister').click(function () {
                var preUsername = $('#username').val();
                 var email = $('#email').val();
                 var tel = $('#tel').val();
                 var password = $('#password').val();
                var url = '/login/registersuc/';
                $.get(url,{'email':email,'username':preUsername,'tel':tel,'password':password},function (data) {
                    $('.suc').html(data.status)
                    location.href = '/axf/home/'

                })
            })
        });