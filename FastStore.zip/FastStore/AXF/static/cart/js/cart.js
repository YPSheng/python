$(document).ready(function(){
    //修改购物车
    var addShoppings = document.getElementsByClassName("addShopping");
    var subShoppings = document.getElementsByClassName("subShopping");

    for (var i = 0; i < addShoppings.length; i++){
        addShopping = addShoppings[i];
        console.log(addShoppings[0]);
        addShopping.addEventListener("click", function(){
            pid = this.getAttribute("ga");
            $.post("/axf/changecart/0/",{"productid":pid}, function(data){
                if (data.status == "success"){
                    // console.log(pid+'price');
                    //添加成功，把中间的span的innerHTML变成当前的数量
                    document.getElementById(pid).innerHTML = data.data;
                    document.getElementById(pid+'price').innerHTML = data.price;
                    document.getElementById('sum').innerHTML = (data.carsum).toFixed(2);
                }
            })
        })
    }

    // 当点击某个商品减号按钮时，减少购物车该商品的数量，并修改此商品的总价格，购物单总商品的总共价钱
    for (var i = 0; i < subShoppings.length; i++){
        // 为每个商品指定唯一
        subShopping = subShoppings[i];
        // 点击减号按钮
        subShopping.addEventListener("click", function(){
            pid = this.getAttribute("ga");
            $.post("/axf/changecart/1/",{"productid":pid}, function(data){
                if (data.status == "success"){
                    //添加成功，把中间的span的innerHTML变成当前的数量
                    document.getElementById(pid).innerHTML = data.data;
                    // 修改该商品的总共价钱
                    document.getElementById(pid+"price").innerHTML = data.price;
                    // 修改所有购物单的总价钱
                    document.getElementById('sum').innerHTML = (data.carsum).toFixed(2);
                    // 如果商品数量减少到为0时
                    if(data.data == 0) {
                        //window.location.href = "http://127.0.0.1:8001/cart/"
                        var div = document.getElementById(pid+"goods")
                        div.parentNode.removeChild(div)
                    }
                }
            })
        })
    }


    // 如果选中购物车商品全面的复选框，就将此商品添加到购物单，并将此商品总价钱添加到总价钱
    var ischoses = document.getElementsByClassName("ischose");
    for (var j = 0; j < ischoses.length; j++){
        // 每个复选框指定唯一
        ischose = ischoses[j];
        // 当点击某个商品复选框时，对这个商品添加到购物单，总价加上此商品总价格
        ischose.addEventListener("click", function(){
            pid = this.getAttribute("goodsid");
            $.post("/axf/changecart/2/", {"productid":pid}, function(data){
                if (data.status == "success"){
                    document.getElementById('sum').innerHTML = (data.carsum).toFixed(2);

                }
            })
        },false)
    }


    // 全选与取消全选
    $('.confirm').click(function () {
        // 先判断全选的复选框是否被选中，然后再判断是全选还是取消全选
        if (this.checked) {
            // 设置所有的复选框的属性为选中
            $('.ischose').prop('checked', true);
            $.post("/axf/checkall/1/",function (data) {
                if (data.status == 'error'){
                    // 如果未登录，跳转到到登录界面
                    window.location.href = "http://127.0.0.1:8000/login/"
                }else if (data.status == 'success'){
                    // 如果登录，修改总共的钱总数
                    document.getElementById('sum').innerHTML = (data.carsum).toFixed(2);
                }

            })
        }else {
            // 取消所有的选中
            $('.ischose').prop('checked',false);
            $.post("/axf/checkall/0/",function (data) {
                if (data.status == 'error'){
                    // 如果未登录，跳转到到登录界面
                    window.location.href = "http://127.0.0.1:8000/login/"
                }else if (data.status == 'success'){
                    // 如果登录，修改总共的钱总数
                    document.getElementById('sum').innerHTML = (data.carsum).toFixed(2);
                }
            })
        }
    });



    // 选好了,提交购物单
    var ok = document.getElementById("ok");
    ok.addEventListener("click", function(){
        var f = confirm("是否确认下单？");
        if (f){
            $.post("/axf/saveorder/", function(data){
                if (data.status = "success"){
                    window.location.href = "http://127.0.0.1:8000/axf/cart/"
                }
            })
        }
    },false)
})