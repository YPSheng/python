// 宽度除以10 作为rem的单位
$(document).ready(function(){
    document.documentElement.style.fontSize = innerWidth / 10 + "px";
})