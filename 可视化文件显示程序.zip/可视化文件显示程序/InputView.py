import tkinter
from tkinter import ttk
from BigDataFind import BigDataFind
class inputView:
    def __init__(self):
        self.win = tkinter.Tk()
        self.win.title("搜索界面")
        self.win.geometry("900x800+0+0")

        self.entry = tkinter.Entry(self.win)
        self.entry.place(x = 10,y = 10)
        self.button = tkinter.Button(self.win,text = "搜索",command = self.search)
        self.button.place(x = 170,y = 5)

        self.combox1 = tkinter.StringVar()
        self.combox1 = ttk.Combobox(self.win,textvariable = self.combox1,width = 80)
        self.combox1["values"] = ("listshow","textshow","tableshow")
        self.combox1.bind("<<ComboboxSelected>>",self.go)
        self.combox1.current(0)
        self.combox1.place(x = 10,y = 50)
        self.howtoshow = "listshow"

        self.combox2 = tkinter.StringVar()
        self.combox2 = ttk.Combobox(self.win, textvariable=self.combox2, width=80)
        self.combox2["values"] = (r"C:\Users\你好\Desktop\kaifanglist.txt",
                                  r"C:\Users\你好\Desktop\csdn2.txt")
        self.combox2.bind("<<ComboboxSelected>>", self.gofile)
        self.combox2.current(0)
        self.combox2.place(x=10, y=100)
        self.howtoshowfile = r"C:\Users\你好\Desktop\kaifanglist.txt"

    def go(self,*args):

        self.howtoshow = self.combox1.get()
    def gofile(self,*args):

        self.howtoshowfile = self.combox2.get()
    def search(self):
        searchstr = self.entry.get()
        big = BigDataFind(self.howtoshow,self.howtoshowfile)
        big.find(searchstr)
        big.show()
    def show(self):
        self.win.mainloop()

a = inputView()
a.show()


