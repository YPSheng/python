import codecs
from TableShow import TableShowView
from ListShow import ListShowView
from TextShow import TextShowView


class  BigDataFind:
    def __init__(self,howtoshow,howtoshowfile):

        self.howtoshow = howtoshow

        self.file = codecs.open(howtoshowfile,"rb","utf-8","ignore")

        if howtoshow == "listshow":
            self.showview = ListShowView()
        elif howtoshow == "textshow":
            self.showview = TextShowView()
        else:
            self.showview = TableShowView()

    def find(self,searchstr):
        while True:
            line = self.file.readline()
            # print(line)
            if line.find(searchstr) != -1:
                self.showview.addata(line)
            if not line:
                break

    def show(self):
        self.showview.show()

    def __del__(self):
        self.file.close()
