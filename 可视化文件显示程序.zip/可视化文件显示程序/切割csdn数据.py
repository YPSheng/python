
path = r"C:\Users\你好\Desktop\csdn.txt"
filelist = []
num = 100
for i in range(num):
    path1 = r"C:\Users\你好\Desktop\python学习\csdn切割文件\\"+"csdn"+ str(i+1)+".txt"
    file = open(path1,"wb")
    filelist.append(file)
i = 0
files1 = open(path,"rb")
while True:
    line = files1.readline()
    if line:
        filelist[i % num - 1].write(line)
    if not line:
        break
    i += 1
files1.close()
for c in filelist:
    c.close()