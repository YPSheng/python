import tkinter
from tkinter import ttk


class TableShowView:
    def __init__(self):
        self.win = tkinter.Tk()
        self.win.title("Table方式显示数据")
        self.win.geometry("900x800+0+0")

        self.table = ttk.Treeview(self.win,height = 900)
        self.table["columns"] = ("name","password","email")
        self.table.column("name",width = 150)
        self.table.column("password", width = 150)
        self.table.column("email", width = 150)

        self.table.heading("name",text = "name-姓名")
        self.table.heading("password",text =  "password-密码")
        self.table.heading("email", text = "email-邮箱")
        self.table.pack()
        self.idnum = 0
    def show(self):
        self.win.mainloop()

    def addata(self,insertstr):
        insertstr1 = insertstr.split("#")
        # print(insertstr1)
        if len(insertstr1) == 3:
            self.table.insert("",self.idnum,text = "line" + str(self.idnum + 1),values = (insertstr1[0],insertstr1[1],insertstr1[2]))
            self.idnum += 1


