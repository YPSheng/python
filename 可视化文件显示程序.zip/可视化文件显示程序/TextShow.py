import tkinter
# from tkinter import ttk

class TextShowView:
    def __init__(self):
        self.win = tkinter.Tk()
        self.win.title("TextShow显示数据")
        self.win.geometry("900x800+0+0")


        self.text = tkinter.Text(self.win,width = 800,height = 900)
        self.text.pack()

    def show(self):
        self.win.mainloop()


    def addata(self,insertstr):
        self.text.insert(tkinter.END,insertstr)
# a = TextShowView()
# a.addata("sadasdad\n")
# a.addata("sadasdad\n")
# a.addata("sadasdad")
# a.show()