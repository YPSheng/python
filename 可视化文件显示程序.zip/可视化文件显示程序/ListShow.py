import tkinter


class ListShowView:
    def __init__(self):
        self.win = tkinter.Tk()
        self.win.title("List显示")
        self.win.geometry("900x800+0+0")

        self.list = tkinter.Listbox(self.win,width = 100,height = 100)
        self.list.pack()


    def show(self):
        self.win.mainloop()

    def addata(self,inseretStr):
        self.list.insert(tkinter.END,inseretStr)
