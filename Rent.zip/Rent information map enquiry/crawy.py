from bs4 import BeautifulSoup
import requests
import csv
import codecs
import time
import random


page = 0
while page < 50:

    csv_file = codecs.open('rent.csv','ab','utf-8','ignore')
    csv_writer = csv.writer(csv_file)

    # while True:
    num =  random.random()*2
    time.sleep(num)
    url = 'http://bj.58.com/pinpaigongyu/pn/{}/?minprice=2000_4000'.format(page)
    page += 1
    print("fetch:",url.format(page=page))

    reponse = requests.get(url.format(str(page))).content
    if reponse == None:
        break
    soup = BeautifulSoup(reponse,'html.parser')
    house_list = soup.select('ul[class="list"] > li')
    for house in house_list:
        # print(house)
        house_title = house.select("h2")[0].text
        # print(house_title)
        house_url = url + house.select("a")[0]["href"]
        house_info_list = house_title.split(' ')
        if '公寓' in house_info_list[1] or '青年社区' in house_info_list[1]:
            house_location = house_info_list[0]
        else:
            house_location = house_info_list[1]
        house_money = house.select(".money")[0].select("b")[0].string
        csv_writer.writerow([house_title,house_location,house_money,house_url])

csv_file.close()